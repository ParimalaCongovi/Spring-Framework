package SpringApplicationContext;

import java.util.List;
import java.util.ArrayList;

public class Triangle {
	private List <Point> points;
	
	public List<Point> getPoints() {
		return points;
	}

	public void setPoints(List<Point> points) {
		this.points = points;
	}

	public void draw()
	{
		points.forEach(p-> System.out.println("Point ("+p.getX()+","+p.getY()+")"));
		
	}

}
