package SpringApplicationContext;

import java.util.List;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import java.util.ArrayList;

public class Triangle {
	/*private Point pointA;
	private Point pointB;*/
	private ApplicationContext context;
	private String beanName;

	/*
	 * public Point getPointA() { return pointA; }
	 * 
	 * public void setPointA(Point pointA) { this.pointA = pointA; }
	 * 
	 * public Point getPointB() { return pointB; }
	 * 
	 * public void setPointB(Point pointB) { this.pointB = pointB; }
	 * 
	 * public Point getPointC() { return pointC; }
	 * 
	 * public void setPointC(Point pointC) { this.pointC = pointC; }
	 * 
	 * private Point pointC;
	 */
	private List <Point> points;
	public void draw()
	{
		/*
		 * System.out.println("Point A ("+getPointA().getX()+","+getPointA().getY()+")")
		 * ;
		 * System.out.println("Point B ("+getPointB().getX()+","+getPointB().getY()+")")
		 * ;
		 * System.out.println("Point C ("+getPointC().getX()+","+getPointC().getY()+")")
		 * ;
		 */
		points.forEach(p->System.out.println("Point ("+p.getX()+","+p.getY()+")"));
	}

	public List<Point> getPoints() {
		return points;
	}

	public void setPoints(List<Point> points) {
		this.points = points;
	}	
	public void myInit()
	{
		System.out.println("My init method called for class Triangle");
	}
	
	public void cleanUp()
	{
		System.out.println("My cleanUp method called for class Triangle");
	}
	
}
