package SpringApplicationContext;

import org.springframework.context.ApplicationEvent;

public class MyEvent extends ApplicationEvent{

	public MyEvent(Object source) {
		super(source);
		// TODO Auto-generated constructor stub
	}
	public String toString()
	{
		return "Draw Event occured." ;
	}

}
