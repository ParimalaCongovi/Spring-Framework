package SpringApplicationContext;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringApplicationContext {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		Shape shape1 = (Shape) context.getBean("circle");
		shape1.draw();
		System.out.println(context.getMessage("gretting",null,"Default Greeting", null));
		context.registerShutdownHook();
		
	}

}
