package SpringApplicationContext;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringApplicationContext {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		Triangle triangle1 = (Triangle) context.getBean("parent-triangle1");
		triangle1.draw();
		context.registerShutdownHook();
		
	}

}
