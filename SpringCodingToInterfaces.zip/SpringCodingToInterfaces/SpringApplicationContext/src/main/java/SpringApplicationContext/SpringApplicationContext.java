package SpringApplicationContext;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringApplicationContext {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		Shape shape = (Shape) context.getBean("parent-triangle1");
		shape.draw();
		Shape shape1 = (Shape) context.getBean("circle");
		shape1.draw();
		context.registerShutdownHook();
		
	}

}
