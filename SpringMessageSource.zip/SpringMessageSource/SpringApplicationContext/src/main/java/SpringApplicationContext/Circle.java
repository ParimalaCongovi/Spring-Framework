package SpringApplicationContext;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
@Component
public class Circle implements Shape{
	private Point center;
	//private int radius;
	private MessageSource messageSource;
	public MessageSource getMessageSource() {
		return messageSource;
	}
	@Autowired
	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}
	public Point getCenter() {
		return center;
	}
	@Resource(name="pointC")
	public void setCenter(Point center) {
		this.center = center;
	}
	@Override
	public void draw() {
		System.out.println(messageSource.getMessage("drawing.circle", null,"Default draw circle",null));
		System.out.println(messageSource.getMessage("drawing.point", new Object[]{center.getX(),center.getY()},"Default Draw Point", null));
		//System.out.println("Radius is "+getRadius());
	}

	
	/*
	 * public int getRadius() { return radius; }
	 * 
	 * @Resource public void setRadius(int radius) { this.radius = radius; }
	 */
	 
}
